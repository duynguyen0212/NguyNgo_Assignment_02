package Assignment_02;

import java.util.ArrayList;

public class Book {
    private String title;
    boolean borrowed;

    public Book(String title) {
        this.title = title;
        borrowed = false;
    }
    public String getTitle(){
        return title;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public void borrowed(){
        this.borrowed = true;
    }
    public void returned(){
        this.borrowed = false;
    }

    public boolean isBorrowed(){
        return borrowed;
    }

    public static void main(String args[]){

    }
}

